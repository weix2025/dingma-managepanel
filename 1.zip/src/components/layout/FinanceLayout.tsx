import FinanceSidebar from '@/components/finance/FinanceSidebar';
import FinanceTopbar from '@/components/finance/FinanceTopbar';
import AnimatedOutlet from '@/components/ui/AnimatedOutlet';

export default function FinanceLayout() {
  return (
    <div className="crm-app-layout">
      <FinanceSidebar />
      <div className="crm-main-area">
        <FinanceTopbar />
        <div className="crm-content">
          <AnimatedOutlet />
        </div>
      </div>
    </div>
  );
}
