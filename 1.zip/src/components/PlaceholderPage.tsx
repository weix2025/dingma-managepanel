export default function PlaceholderPage({ title }: { title: string }) {
  return (
    <div style={{ padding: 40, textAlign: 'center' }}>
      <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.6 }}>🚧</div>
      <h2 style={{ color: 'var(--text-primary)', marginBottom: 8 }}>{title}</h2>
      <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>此模块正在开发中，敬请期待</p>
      <div style={{
        display: 'inline-flex', padding: '10px 20px',
        background: 'var(--bg-card)', border: '1px solid var(--border-color)',
        borderRadius: 'var(--radius-md)', fontSize: 13, color: 'var(--text-secondary)',
      }}>
        预计上线时间：Q3 2025
      </div>
    </div>
  );
}
