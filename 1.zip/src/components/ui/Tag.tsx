import type { ReactNode } from 'react';
import './Tag.css';

export default function Tag({ color = 'blue', children }: { color?: string; children: ReactNode }) {
  return <span className={`tag tag-${color}`}>{children}</span>;
}
