import { useState } from 'react';
import { Link, useLocation } from '@modern-js/runtime/router';
import '../crm/CrmSidebar.css';

const navItems = [
  { key: '/finance/dashboard', label: '财务总览', icon: 'dashboard' },
  { key: '/finance/accounts', label: '会计科目', icon: 'accounts' },
  { key: '/finance/vouchers', label: '凭证管理', icon: 'voucher' },
  { key: '/finance/ledger', label: '账簿查询', icon: 'ledger' },
  { key: '/finance/statements', label: '财务报表', icon: 'statement' },
  { key: '/finance/budget', label: '预算管理', icon: 'budget' },
  { key: '/finance/expense', label: '报销审批', icon: 'expense' },
  { key: '/finance/invoice', label: '发票管理', icon: 'invoice' },
  { key: '/finance/tax', label: '税务申报', icon: 'tax' },
];

const advancedItems = [
  { key: '/finance/assets', label: '固定资产' },
  { key: '/finance/cost', label: '成本核算' },
  { key: '/finance/multi-currency', label: '多币种' },
  { key: '/finance/reconciliation', label: '自动对账' },
  { key: '/finance/consolidation', label: '合并报表' },
  { key: '/finance/settings', label: '财务设置' },
];

const icons: Record<string, React.ReactNode> = {
  dashboard: <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
  accounts: <svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>,
  voucher: <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>,
  ledger: <svg viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
  statement: <svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
  budget: <svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
  expense: <svg viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
  invoice: <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  tax: <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  advanced: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
};

export default function FinanceSidebar() {
  const { pathname } = useLocation();
  const [advOpen, setAdvOpen] = useState(pathname.startsWith('/finance/assets') || pathname.startsWith('/finance/cost') || pathname.startsWith('/finance/multi') || pathname.startsWith('/finance/recon') || pathname.startsWith('/finance/consol') || pathname.startsWith('/finance/settings'));

  return (
    <aside className="crm-sidebar">
      <div className="crm-sidebar-logo">CORDYS 财务</div>
      <nav className="crm-sidebar-nav">
        {navItems.map(n => (
          <Link key={n.key} to={n.key} className={`crm-nav-item${pathname.startsWith(n.key) ? ' active' : ''}`}>
            <span className="nav-icon">{icons[n.icon]}</span>
            <span>{n.label}</span>
          </Link>
        ))}
        <div
          className={`crm-nav-item${advOpen ? ' expanded' : ''}`}
          onClick={() => setAdvOpen(!advOpen)}
        >
          <span className="nav-icon">{icons.advanced}</span>
          <span>高级</span>
          <span className="expand-arrow"><svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg></span>
        </div>
        <div className={`crm-sub-nav${advOpen ? ' open' : ''}`}>
          {advancedItems.map(s => (
            <Link key={s.key} to={s.key} className={`crm-nav-item${pathname.startsWith(s.key) ? ' active' : ''}`}>
              <span>{s.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </aside>
  );
}
