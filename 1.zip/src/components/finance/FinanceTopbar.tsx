import { useTheme } from '@/context/ThemeContext';
import SearchInput from '@/components/ui/SearchInput';
import Tooltip from '@/components/ui/Tooltip';
import { Link } from '@modern-js/runtime/router';
import './FinanceTopbar.css';

export default function FinanceTopbar() {
  const { theme, toggle } = useTheme();
  return (
    <header className="crm-topbar">
      <Link to="/crm/opportunities" className="topbar-back">← CRM</Link>
      <SearchInput placeholder="搜索科目/凭证... Ctrl+K" className="topbar-search" />
      <Tooltip content="通知">
        <div className="topbar-icon">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        </div>
      </Tooltip>
      <button className="theme-toggle" onClick={toggle}>
        {theme === 'dark' ? '☀️ 白天' : '🌙 夜间'}
      </button>
    </header>
  );
}
