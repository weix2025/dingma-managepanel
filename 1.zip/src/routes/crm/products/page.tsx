import SearchInput from '@/components/ui/SearchInput';
import Button from '@/components/ui/Button';
import Tag from '@/components/ui/Tag';
import './page.css';

const products = [
  { name: 'CRM 标准版', code: 'PRD-001', category: '软件', price: '¥98,000/年', status: '在售' },
  { name: 'CRM 企业版', code: 'PRD-002', category: '软件', price: '¥298,000/年', status: '在售' },
  { name: '数据分析平台', code: 'PRD-003', category: '平台', price: '¥158,000/年', status: '在售' },
  { name: 'AI 智能体模块', code: 'PRD-004', category: '增值', price: '¥68,000/年', status: '预售' },
  { name: '实施服务包', code: 'SVC-001', category: '服务', price: '¥50,000/次', status: '在售' },
  { name: '定制开发服务', code: 'SVC-002', category: '服务', price: '面议', status: '在售' },
];

const statusColor: Record<string, string> = { '在售': 'green', '预售': 'blue', '停售': 'default' };

export default function ProductsPage() {
  return (
    <>
      <div className="leads-header">
        <h2>产品管理</h2>
        <div className="leads-actions">
          <SearchInput placeholder="搜索产品..." />
          <Button variant="primary">新建产品</Button>
        </div>
      </div>
      <table className="leads-table">
        <thead><tr><th>产品名称</th><th>编码</th><th>分类</th><th>价格</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          {products.map(p => (
            <tr key={p.code}>
              <td className="name-cell">{p.name}</td>
              <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{p.code}</td>
              <td>{p.category}</td>
              <td>{p.price}</td>
              <td><Tag color={statusColor[p.status]}>{p.status}</Tag></td>
              <td className="op-cell"><a href="#">编辑</a></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
