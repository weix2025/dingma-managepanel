import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import SearchInput from '@/components/ui/SearchInput';
import Button from '@/components/ui/Button';
import Tag from '@/components/ui/Tag';
import './page.css';

const customers = [
  { name: '某某科技有限公司', contact: '张明', industry: '信息技术', level: 'A', amount: '¥1,280,000', status: '活跃' },
  { name: '创新软件股份', contact: '李芳', industry: '软件服务', level: 'A', amount: '¥960,000', status: '活跃' },
  { name: '数据智能科技', contact: '王强', industry: '人工智能', level: 'B', amount: '¥520,000', status: '活跃' },
  { name: '云端网络技术', contact: '赵丽', industry: '云计算', level: 'B', amount: '¥380,000', status: '沉默' },
  { name: '未来制造集团', contact: '陈伟', industry: '智能制造', level: 'C', amount: '¥150,000', status: '沉默' },
  { name: '绿色能源科技', contact: '刘洋', industry: '新能源', level: 'A', amount: '¥720,000', status: '活跃' },
];

const levelColor: Record<string, string> = { A: 'green', B: 'blue', C: 'default' };
const statusColor: Record<string, string> = { '活跃': 'green', '沉默': 'orange' };

export default function CustomersPage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="leads-header">
        <h2>客户管理</h2>
        <div className="leads-actions">
          <SearchInput placeholder="搜索客户..." />
          <Button variant="primary">新建客户</Button>
        </div>
      </div>
      <Tabs items={['全部', '活跃', '沉默']} active={tab} onChange={setTab} />
      <table className="leads-table">
        <thead><tr><th>公司名称</th><th>联系人</th><th>行业</th><th>等级</th><th>累计金额</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
          {customers.map(c => (
            <tr key={c.name}>
              <td className="name-cell">{c.name}</td>
              <td>{c.contact}</td>
              <td>{c.industry}</td>
              <td><Tag color={levelColor[c.level]}>{c.level}</Tag></td>
              <td style={{ fontFamily: 'monospace' }}>{c.amount}</td>
              <td><Tag color={statusColor[c.status]}>{c.status}</Tag></td>
              <td className="op-cell"><a href="#">详情</a></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
