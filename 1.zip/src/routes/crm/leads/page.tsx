import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import SearchInput from '@/components/ui/SearchInput';
import Button from '@/components/ui/Button';
import Tag from '@/components/ui/Tag';
import './page.css';

const leads = [
  { name: '张明', company: '某某科技有限公司', phone: '138****1234', source: '官网', status: '新线索', time: '2025-08-12' },
  { name: '李芳', company: '创新软件股份', phone: '139****5678', source: '展会', status: '跟进中', time: '2025-08-11' },
  { name: '王强', company: '数据智能科技', phone: '136****9012', source: '转介绍', status: '已转化', time: '2025-08-10' },
  { name: '赵丽', company: '云端网络技术', phone: '137****3456', source: '广告', status: '跟进中', time: '2025-08-09' },
  { name: '陈伟', company: '未来制造集团', phone: '135****7890', source: '官网', status: '无效', time: '2025-08-08' },
  { name: '刘洋', company: '绿色能源科技', phone: '133****2345', source: '电话', status: '新线索', time: '2025-08-07' },
];

const statusColor: Record<string, string> = { '新线索': 'blue', '跟进中': 'orange', '已转化': 'green', '无效': 'default' };

export default function LeadsPage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="leads-header">
        <h2>线索管理</h2>
        <div className="leads-actions">
          <SearchInput placeholder="搜索线索..." />
          <Button variant="outline">导入</Button>
          <Button variant="primary">新建线索</Button>
        </div>
      </div>
      <Tabs items={['全部', '新线索', '跟进中', '已转化']} active={tab} onChange={setTab} />
      <table className="leads-table">
        <thead><tr><th>姓名</th><th>公司</th><th>电话</th><th>来源</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead>
        <tbody>
          {leads.map(l => (
            <tr key={l.name + l.company}>
              <td className="name-cell">{l.name}</td>
              <td>{l.company}</td>
              <td>{l.phone}</td>
              <td>{l.source}</td>
              <td><Tag color={statusColor[l.status]}>{l.status}</Tag></td>
              <td>{l.time}</td>
              <td className="op-cell"><a href="#">编辑</a><a href="#">转化</a></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
