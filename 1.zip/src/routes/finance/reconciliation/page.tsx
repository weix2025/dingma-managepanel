import './page.css';

const items = [
  { date: '2025-08-12', bank: '工商银行', bankAmt: '285,000.00', bookAmt: '285,000.00', status: '已匹配' },
  { date: '2025-08-11', bank: '工商银行', bankAmt: '152,300.00', bookAmt: '152,300.00', status: '已匹配' },
  { date: '2025-08-10', bank: '建设银行', bankAmt: '45,000.00', bookAmt: '45,000.00', status: '已匹配' },
  { date: '2025-08-09', bank: '工商银行', bankAmt: '18,200.00', bookAmt: '', status: '未匹配' },
  { date: '2025-08-08', bank: '建设银行', bankAmt: '', bookAmt: '6,500.00', status: '未匹配' },
];

const sc: Record<string, string> = { '已匹配': 'green', '未匹配': 'orange' };

export default function ReconciliationPage() {
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">自动对账</h2>
        <button type="button" className="btn btn-primary">开始对账</button>
      </div>
      <div className="recon-stats">
        <div className="recon-stat"><span className="recon-label">匹配率</span><span className="recon-value">85.7%</span></div>
        <div className="recon-stat"><span className="recon-label">未匹配</span><span className="recon-value warn">2</span></div>
      </div>
      <table className="fin-table">
        <thead><tr><th>日期</th><th>银行</th><th>银行金额</th><th>账面金额</th><th>状态</th></tr></thead>
        <tbody>
          {items.map((r, i) => (
            <tr key={i}>
              <td>{r.date}</td><td>{r.bank}</td>
              <td className="num-cell">{r.bankAmt || '—'}</td>
              <td className="num-cell">{r.bookAmt || '—'}</td>
              <td><span className={`fin-tag ${sc[r.status]}`}>{r.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
