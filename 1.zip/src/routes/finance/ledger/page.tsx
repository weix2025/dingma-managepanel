import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import './page.css';

const tabs = ['总账', '明细账', '余额表'];

const ledgerData = [
  { code: '1002', name: '银行存款', opening: '2,500,000.00', debit: '847,600.00', credit: '500,000.00', closing: '2,847,600.00' },
  { code: '1122', name: '应收账款', opening: '3,800,000.00', debit: '1,215,800.00', credit: '800,000.00', closing: '4,215,800.00' },
  { code: '2202', name: '应付账款', opening: '1,850,000.00', debit: '243,700.00', credit: '500,000.00', closing: '2,106,300.00' },
  { code: '6001', name: '主营业务收入', opening: '6,200,000.00', debit: '0.00', credit: '2,347,200.00', closing: '8,547,200.00' },
  { code: '6401', name: '主营业务成本', opening: '3,800,000.00', debit: '1,328,300.00', credit: '0.00', closing: '5,128,300.00' },
  { code: '6602', name: '管理费用', opening: '920,000.00', debit: '325,600.00', credit: '0.00', closing: '1,245,600.00' },
];

export default function LedgerPage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">账簿查询</h2>
        <select className="fin-select"><option>2025年8月</option><option>2025年7月</option></select>
      </div>
      <Tabs items={tabs} active={tab} onChange={setTab} />
      <table className="fin-table" style={{ marginTop: 14 }}>
        <thead><tr><th>科目编码</th><th>科目名称</th><th>期初余额</th><th>本期借方</th><th>本期贷方</th><th>期末余额</th></tr></thead>
        <tbody>
          {ledgerData.map(r => (
            <tr key={r.code}>
              <td className="code-cell">{r.code}</td>
              <td>{r.name}</td>
              <td className="num-cell">{r.opening}</td>
              <td className="num-cell">{r.debit}</td>
              <td className="num-cell">{r.credit}</td>
              <td className="num-cell" style={{ fontWeight: 600 }}>{r.closing}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
