import { useState } from 'react';
import Toggle from '@/components/ui/Toggle';
import './page.css';

const periods = [
  { name: '2025年8月', start: '2025-08-01', end: '2025-08-31', status: '当前' },
  { name: '2025年7月', start: '2025-07-01', end: '2025-07-31', status: '已结账' },
  { name: '2025年6月', start: '2025-06-01', end: '2025-06-30', status: '已结账' },
];

const sc: Record<string, string> = { '当前': 'blue', '已结账': 'green' };

export default function SettingsPage() {
  const [autoAudit, setAutoAudit] = useState(false);
  const [multiCur, setMultiCur] = useState(true);

  return (
    <>
      <h2 className="fin-page-title">财务设置</h2>
      <div className="settings-section">
        <h3>会计期间</h3>
        <table className="fin-table">
          <thead><tr><th>期间</th><th>开始</th><th>结束</th><th>状态</th></tr></thead>
          <tbody>
            {periods.map(p => (
              <tr key={p.name}>
                <td>{p.name}</td><td>{p.start}</td><td>{p.end}</td>
                <td><span className={`fin-tag ${sc[p.status]}`}>{p.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="settings-section">
        <h3>审批流程</h3>
        <div className="setting-row">
          <span>凭证自动审核</span>
          <Toggle active={autoAudit} onChange={() => setAutoAudit(!autoAudit)} />
        </div>
        <div className="setting-row">
          <span>启用多币种</span>
          <Toggle active={multiCur} onChange={() => setMultiCur(!multiCur)} />
        </div>
      </div>
    </>
  );
}
