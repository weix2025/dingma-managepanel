import { useState } from 'react';
import SearchInput from '@/components/ui/SearchInput';
import './page.css';

const accounts = [
  { code: '1001', name: '库存现金', type: '资产', balance: '15,230.00', level: 1 },
  { code: '1002', name: '银行存款', type: '资产', balance: '2,847,600.00', level: 1 },
  { code: '100201', name: '工商银行', type: '资产', balance: '1,523,400.00', level: 2 },
  { code: '100202', name: '建设银行', type: '资产', balance: '1,324,200.00', level: 2 },
  { code: '1122', name: '应收账款', type: '资产', balance: '4,215,800.00', level: 1 },
  { code: '1403', name: '原材料', type: '资产', balance: '856,300.00', level: 1 },
  { code: '1601', name: '固定资产', type: '资产', balance: '3,200,000.00', level: 1 },
  { code: '2001', name: '短期借款', type: '负债', balance: '500,000.00', level: 1 },
  { code: '2202', name: '应付账款', type: '负债', balance: '2,106,300.00', level: 1 },
  { code: '4001', name: '实收资本', type: '所有者权益', balance: '5,000,000.00', level: 1 },
  { code: '5001', name: '生产成本', type: '成本', balance: '423,100.00', level: 1 },
  { code: '6001', name: '主营业务收入', type: '损益', balance: '8,547,200.00', level: 1 },
  { code: '6401', name: '主营业务成本', type: '损益', balance: '5,128,300.00', level: 1 },
  { code: '6602', name: '管理费用', type: '损益', balance: '1,245,600.00', level: 1 },
  { code: '6603', name: '财务费用', type: '损益', balance: '86,400.00', level: 1 },
];

const typeColors: Record<string, string> = { '资产': 'blue', '负债': 'orange', '所有者权益': 'purple', '成本': 'cyan', '损益': 'green' };

export default function AccountsPage() {
  const [search, setSearch] = useState('');
  const filtered = accounts.filter(a => a.name.includes(search) || a.code.includes(search));

  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">会计科目</h2>
        <div className="fin-header-actions">
          <SearchInput placeholder="搜索科目编码/名称" value={search} onChange={setSearch} />
          <button type="button" className="btn btn-primary">新增科目</button>
        </div>
      </div>
      <table className="fin-table">
        <thead><tr><th>科目编码</th><th>科目名称</th><th>类别</th><th>期末余额</th><th>操作</th></tr></thead>
        <tbody>
          {filtered.map(a => (
            <tr key={a.code} className={a.level === 2 ? 'child-row' : ''}>
              <td className="code-cell">{a.code}</td>
              <td style={{ paddingLeft: a.level === 2 ? 32 : 0 }}>{a.name}</td>
              <td><span className={`fin-tag ${typeColors[a.type]}`}>{a.type}</span></td>
              <td className="num-cell">{a.balance}</td>
              <td className="op-cell"><button type="button">编辑</button><button type="button">明细</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
