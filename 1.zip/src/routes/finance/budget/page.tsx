import { useECharts } from '@/hooks/useECharts';
import './page.css';

const depts = [
  { name: '研发部', budget: 500, used: 380, rate: 76 },
  { name: '市场部', budget: 300, used: 252, rate: 84 },
  { name: '销售部', budget: 250, used: 198, rate: 79 },
  { name: '行政部', budget: 150, used: 112, rate: 75 },
  { name: '人力资源', budget: 120, used: 95, rate: 79 },
  { name: '财务部', budget: 80, used: 54, rate: 68 },
];

const barOption = {
  tooltip: { trigger: 'axis' },
  legend: { data: ['预算','已用'], textStyle: { color: '#9898a6', fontSize: 11 } },
  grid: { left: 80, right: 16, top: 36, bottom: 24 },
  yAxis: { type: 'category', data: depts.map(d => d.name), axisLabel: { color: '#6a6a78' }, axisLine: { lineStyle: { color: '#2a2a35' } } },
  xAxis: { type: 'value', axisLabel: { color: '#6a6a78', formatter: (v: number) => `${v}万` }, splitLine: { lineStyle: { color: '#2a2a35' } } },
  series: [
    { name: '预算', type: 'bar', data: depts.map(d => d.budget), itemStyle: { color: '#3b82f6' } },
    { name: '已用', type: 'bar', data: depts.map(d => d.used), itemStyle: { color: '#22c55e' } },
  ],
};

function Chart({ option }: { option: any }) {
  const ref = useECharts(option);
  return <div ref={ref} style={{ width: '100%', height: 300 }} />;
}

export default function BudgetPage() {
  return (
    <>
      <h2 className="fin-page-title">预算管理</h2>
      <div className="budget-chart-card">
        <div className="fin-chart-title">部门预算执行情况</div>
        <Chart option={barOption} />
      </div>
      <table className="fin-table" style={{ marginTop: 16 }}>
        <thead><tr><th>部门</th><th>年度预算(万)</th><th>已使用(万)</th><th>执行率</th><th>状态</th></tr></thead>
        <tbody>
          {depts.map(d => (
            <tr key={d.name}>
              <td>{d.name}</td>
              <td className="num-cell">{d.budget}</td>
              <td className="num-cell">{d.used}</td>
              <td className="num-cell">
                <div className="rate-bar"><div className="rate-fill" style={{ width: `${d.rate}%` }} /></div>
                {d.rate}%
              </td>
              <td><span className={`fin-tag ${d.rate > 80 ? 'orange' : 'green'}`}>{d.rate > 80 ? '预警' : '正常'}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
