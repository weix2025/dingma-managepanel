import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import './page.css';

const invoices = [
  { id: 'FP-2025-0089', type: '销项', buyer: '某某科技', amount: '285,000.00', tax: '37,050.00', date: '2025-08-12', status: '已开票' },
  { id: 'FP-2025-0088', type: '进项', seller: '供应商A', amount: '152,300.00', tax: '19,799.00', date: '2025-08-11', status: '已认证' },
  { id: 'FP-2025-0087', type: '销项', buyer: '某某集团', amount: '420,000.00', tax: '54,600.00', date: '2025-08-10', status: '待开票' },
  { id: 'FP-2025-0086', type: '进项', seller: '供应商B', amount: '86,500.00', tax: '11,245.00', date: '2025-08-09', status: '待认证' },
  { id: 'FP-2025-0085', type: '销项', buyer: '某某信息', amount: '198,000.00', tax: '25,740.00', date: '2025-08-08', status: '已开票' },
];

const statusColors: Record<string, string> = { '已开票': 'green', '待开票': 'orange', '已认证': 'blue', '待认证': 'orange', '已作废': 'red' };

export default function InvoicePage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">发票管理</h2>
        <button type="button" className="btn btn-primary">开具发票</button>
      </div>
      <Tabs items={['全部', '销项发票', '进项发票', '待认证']} active={tab} onChange={setTab} />
      <table className="fin-table" style={{ marginTop: 14 }}>
        <thead><tr><th>发票号</th><th>类型</th><th>对方</th><th>金额</th><th>税额</th><th>日期</th><th>状态</th></tr></thead>
        <tbody>
          {invoices.map(inv => (
            <tr key={inv.id}>
              <td className="code-cell">{inv.id}</td>
              <td><span className={`fin-tag ${inv.type === '销项' ? 'green' : 'blue'}`}>{inv.type}</span></td>
              <td>{inv.buyer || inv.seller}</td>
              <td className="num-cell">{inv.amount}</td>
              <td className="num-cell">{inv.tax}</td>
              <td>{inv.date}</td>
              <td><span className={`fin-tag ${statusColors[inv.status]}`}>{inv.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
