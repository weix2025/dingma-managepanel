import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import './page.css';

const tabs = ['资产负债表', '利润表', '现金流量表'];

type Row = { name: string; bold?: boolean; opening: string; closing: string };

const balanceSheet: Row[] = [
  { name: '流动资产', bold: true, opening: '', closing: '' },
  { name: '  货币资金', opening: '2,500,000.00', closing: '2,862,830.00' },
  { name: '  应收账款', opening: '3,800,000.00', closing: '4,215,800.00' },
  { name: '  存货', opening: '920,000.00', closing: '856,300.00' },
  { name: '流动资产合计', bold: true, opening: '7,220,000.00', closing: '7,934,930.00' },
  { name: '非流动资产', bold: true, opening: '', closing: '' },
  { name: '  固定资产', opening: '3,200,000.00', closing: '3,200,000.00' },
  { name: '  累计折旧', opening: '-360,000.00', closing: '-480,000.00' },
  { name: '非流动资产合计', bold: true, opening: '2,840,000.00', closing: '2,720,000.00' },
  { name: '资产总计', bold: true, opening: '10,060,000.00', closing: '10,654,930.00' },
  { name: '', opening: '', closing: '' },
  { name: '流动负债', bold: true, opening: '', closing: '' },
  { name: '  短期借款', opening: '500,000.00', closing: '500,000.00' },
  { name: '  应付账款', opening: '1,850,000.00', closing: '2,106,300.00' },
  { name: '流动负债合计', bold: true, opening: '2,350,000.00', closing: '2,606,300.00' },
  { name: '所有者权益', bold: true, opening: '', closing: '' },
  { name: '  实收资本', opening: '5,000,000.00', closing: '5,000,000.00' },
  { name: '  未分配利润', opening: '2,710,000.00', closing: '3,048,630.00' },
  { name: '所有者权益合计', bold: true, opening: '7,710,000.00', closing: '8,048,630.00' },
  { name: '负债和所有者权益总计', bold: true, opening: '10,060,000.00', closing: '10,654,930.00' },
];

const incomeStatement: Row[] = [
  { name: '一、营业收入', bold: true, opening: '6,200,000.00', closing: '8,547,200.00' },
  { name: '  减：营业成本', opening: '3,800,000.00', closing: '5,128,300.00' },
  { name: '  减：税金及附加', opening: '62,000.00', closing: '85,470.00' },
  { name: '  减：销售费用', opening: '310,000.00', closing: '427,360.00' },
  { name: '  减：管理费用', opening: '620,000.00', closing: '854,720.00' },
  { name: '  减：财务费用', opening: '45,000.00', closing: '62,500.00' },
  { name: '二、营业利润', bold: true, opening: '1,363,000.00', closing: '1,988,850.00' },
  { name: '  加：营业外收入', opening: '15,000.00', closing: '22,000.00' },
  { name: '  减：营业外支出', opening: '8,000.00', closing: '5,200.00' },
  { name: '三、利润总额', bold: true, opening: '1,370,000.00', closing: '2,005,650.00' },
  { name: '  减：所得税费用', opening: '342,500.00', closing: '501,412.50' },
  { name: '四、净利润', bold: true, opening: '1,027,500.00', closing: '1,504,237.50' },
];

const cashFlow: Row[] = [
  { name: '一、经营活动产生的现金流量', bold: true, opening: '', closing: '' },
  { name: '  销售商品收到的现金', opening: '5,800,000.00', closing: '8,120,000.00' },
  { name: '  购买商品支付的现金', opening: '-3,500,000.00', closing: '-4,860,000.00' },
  { name: '  支付给职工的现金', opening: '-980,000.00', closing: '-1,350,000.00' },
  { name: '  支付的各项税费', opening: '-404,500.00', closing: '-586,882.50' },
  { name: '经营活动现金流量净额', bold: true, opening: '915,500.00', closing: '1,323,117.50' },
  { name: '二、投资活动产生的现金流量', bold: true, opening: '', closing: '' },
  { name: '  购建固定资产支付的现金', opening: '-200,000.00', closing: '-150,000.00' },
  { name: '  取得投资收益收到的现金', opening: '15,000.00', closing: '22,000.00' },
  { name: '投资活动现金流量净额', bold: true, opening: '-185,000.00', closing: '-128,000.00' },
  { name: '三、筹资活动产生的现金流量', bold: true, opening: '', closing: '' },
  { name: '  取得借款收到的现金', opening: '500,000.00', closing: '0.00' },
  { name: '  偿还债务支付的现金', opening: '-300,000.00', closing: '0.00' },
  { name: '  分配股利支付的现金', opening: '-200,000.00', closing: '-300,000.00' },
  { name: '筹资活动现金流量净额', bold: true, opening: '0.00', closing: '-300,000.00' },
  { name: '', opening: '', closing: '' },
  { name: '现金及现金等价物净增加额', bold: true, opening: '730,500.00', closing: '895,117.50' },
];

const datasets = [balanceSheet, incomeStatement, cashFlow];
const headers = [
  ['项目', '期初余额', '期末余额'],
  ['项目', '上年累计', '本年累计'],
  ['项目', '上年金额', '本年金额'],
];

export default function StatementsPage() {
  const [tab, setTab] = useState(0);
  const data = datasets[tab];
  const hdr = headers[tab];
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">财务报表</h2>
        <div className="fin-header-actions">
          <select className="fin-select"><option>2025年8月</option></select>
          <button type="button" className="btn btn-outline">导出Excel</button>
        </div>
      </div>
      <Tabs items={tabs} active={tab} onChange={setTab} />
      <table className="fin-table stmt-table" style={{ marginTop: 14 }}>
        <thead><tr><th>{hdr[0]}</th><th>{hdr[1]}</th><th>{hdr[2]}</th></tr></thead>
        <tbody>
          {data.map((r, i) => (
            <tr key={i} className={r.bold ? 'bold-row' : ''}>
              <td>{r.name}</td>
              <td className="num-cell">{r.opening}</td>
              <td className="num-cell">{r.closing}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
