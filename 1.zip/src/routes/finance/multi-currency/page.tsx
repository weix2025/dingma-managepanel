import './page.css';

const currencies = [
  { code: 'USD', name: '美元', rate: '7.2450', account: '1,245,000.00', cny: '9,019,825.00', updated: '2025-08-12' },
  { code: 'EUR', name: '欧元', rate: '7.8920', account: '380,000.00', cny: '2,998,960.00', updated: '2025-08-12' },
  { code: 'JPY', name: '日元', rate: '0.0485', account: '15,600,000', cny: '756,600.00', updated: '2025-08-12' },
  { code: 'HKD', name: '港币', rate: '0.9280', account: '520,000.00', cny: '482,560.00', updated: '2025-08-12' },
];

export default function MultiCurrencyPage() {
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">多币种管理</h2>
        <button type="button" className="btn btn-outline">更新汇率</button>
      </div>
      <table className="fin-table">
        <thead><tr><th>币种</th><th>名称</th><th>汇率(CNY)</th><th>外币余额</th><th>折合人民币</th><th>更新时间</th></tr></thead>
        <tbody>
          {currencies.map(c => (
            <tr key={c.code}>
              <td className="code-cell">{c.code}</td>
              <td>{c.name}</td>
              <td className="num-cell">{c.rate}</td>
              <td className="num-cell">{c.account}</td>
              <td className="num-cell" style={{ fontWeight: 600 }}>{c.cny}</td>
              <td>{c.updated}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
