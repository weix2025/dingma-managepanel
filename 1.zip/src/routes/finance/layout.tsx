import FinanceLayout from '@/components/layout/FinanceLayout';

export default function FinanceRouteLayout() {
  return <FinanceLayout />;
}
