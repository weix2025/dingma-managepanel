import './page.css';

const assets = [
  { code: 'FA-001', name: '办公楼', category: '房屋建筑', original: '2,000,000.00', depreciation: '320,000.00', net: '1,680,000.00', method: '直线法', life: '20年' },
  { code: 'FA-002', name: '生产设备A', category: '机器设备', original: '500,000.00', depreciation: '100,000.00', net: '400,000.00', method: '直线法', life: '10年' },
  { code: 'FA-003', name: '运输车辆', category: '运输工具', original: '350,000.00', depreciation: '42,000.00', net: '308,000.00', method: '双倍余额', life: '5年' },
  { code: 'FA-004', name: '服务器集群', category: '电子设备', original: '280,000.00', depreciation: '14,000.00', net: '266,000.00', method: '直线法', life: '5年' },
  { code: 'FA-005', name: '办公家具', category: '办公设备', original: '70,000.00', depreciation: '4,000.00', net: '66,000.00', method: '直线法', life: '5年' },
];

export default function AssetsPage() {
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">固定资产</h2>
        <div className="fin-header-actions">
          <button type="button" className="btn btn-outline">计提折旧</button>
          <button type="button" className="btn btn-primary">新增资产</button>
        </div>
      </div>
      <table className="fin-table">
        <thead><tr><th>编号</th><th>名称</th><th>类别</th><th>原值</th><th>累计折旧</th><th>净值</th><th>折旧方法</th><th>使用年限</th></tr></thead>
        <tbody>
          {assets.map(a => (
            <tr key={a.code}>
              <td className="code-cell">{a.code}</td>
              <td>{a.name}</td>
              <td>{a.category}</td>
              <td className="num-cell">{a.original}</td>
              <td className="num-cell">{a.depreciation}</td>
              <td className="num-cell" style={{ fontWeight: 600 }}>{a.net}</td>
              <td>{a.method}</td>
              <td>{a.life}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
