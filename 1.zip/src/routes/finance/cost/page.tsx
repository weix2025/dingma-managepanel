import './page.css';

const centers = [
  { code: 'CC-01', name: '生产车间', type: '直接成本', budget: '180,000', actual: '172,400', variance: '-7,600', rate: '95.8%' },
  { code: 'CC-02', name: '研发中心', type: '间接成本', budget: '250,000', actual: '238,500', variance: '-11,500', rate: '95.4%' },
  { code: 'CC-03', name: '物流仓储', type: '直接成本', budget: '95,000', actual: '102,300', variance: '+7,300', rate: '107.7%' },
  { code: 'CC-04', name: '质检部门', type: '间接成本', budget: '60,000', actual: '55,800', variance: '-4,200', rate: '93.0%' },
  { code: 'CC-05', name: '行政管理', type: '期间费用', budget: '45,000', actual: '43,200', variance: '-1,800', rate: '96.0%' },
];

export default function CostPage() {
  return (
    <>
      <h2 className="fin-page-title">成本核算</h2>
      <table className="fin-table">
        <thead><tr><th>编号</th><th>成本中心</th><th>类型</th><th>预算</th><th>实际</th><th>差异</th><th>执行率</th></tr></thead>
        <tbody>
          {centers.map(c => (
            <tr key={c.code}>
              <td className="code-cell">{c.code}</td>
              <td>{c.name}</td>
              <td><span className={`fin-tag ${c.type === '直接成本' ? 'blue' : c.type === '间接成本' ? 'purple' : 'orange'}`}>{c.type}</span></td>
              <td className="num-cell">{c.budget}</td>
              <td className="num-cell">{c.actual}</td>
              <td className={`num-cell ${c.variance.startsWith('+') ? 'over' : 'under'}`}>{c.variance}</td>
              <td className="num-cell">{c.rate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
