import { useECharts } from '@/hooks/useECharts';
import './page.css';

function Chart({ option, className }: { option: any; className?: string }) {
  const ref = useECharts(option);
  return <div ref={ref} className={className || 'fin-chart'} />;
}

const kpis = [
  { label: '本月收入', value: '¥2,847,600', change: '+12.5%', up: true },
  { label: '本月支出', value: '¥1,523,400', change: '+3.2%', up: false },
  { label: '应收账款', value: '¥4,215,800', change: '-8.1%', up: true },
  { label: '应付账款', value: '¥2,106,300', change: '+5.7%', up: false },
];

const months = ['1月','2月','3月','4月','5月','6月','7月','8月'];
const trendOption = {
  tooltip: { trigger: 'axis' },
  legend: { data: ['收入','支出'], textStyle: { color: '#9898a6', fontSize: 11 } },
  grid: { left: 50, right: 16, top: 36, bottom: 24 },
  xAxis: { type: 'category', data: months, axisLabel: { color: '#6a6a78' }, axisLine: { lineStyle: { color: '#2a2a35' } } },
  yAxis: { type: 'value', axisLabel: { color: '#6a6a78', formatter: (v: number) => `${v / 10000}万` }, splitLine: { lineStyle: { color: '#2a2a35' } } },
  series: [
    { name: '收入', type: 'line', smooth: true, data: [180,220,195,260,240,285,310,285].map(v => v * 10000), areaStyle: { color: 'rgba(34,197,94,0.1)' }, lineStyle: { color: '#22c55e' }, itemStyle: { color: '#22c55e' } },
    { name: '支出', type: 'line', smooth: true, data: [120,135,140,155,148,160,172,152].map(v => v * 10000), areaStyle: { color: 'rgba(239,68,68,0.1)' }, lineStyle: { color: '#ef4444' }, itemStyle: { color: '#ef4444' } },
  ],
};

const arApOption = {
  tooltip: { trigger: 'item', formatter: '{b}: {d}%' },
  legend: { orient: 'vertical', right: 10, top: 'center', textStyle: { color: '#9898a6', fontSize: 11 } },
  series: [{ type: 'pie', radius: ['45%','70%'], center: ['35%','50%'], label: { show: false },
    data: [
      { value: 42, name: '0-30天', itemStyle: { color: '#22c55e' } },
      { value: 28, name: '31-60天', itemStyle: { color: '#3b82f6' } },
      { value: 18, name: '61-90天', itemStyle: { color: '#f59e0b' } },
      { value: 12, name: '90天以上', itemStyle: { color: '#ef4444' } },
    ],
  }],
};

const costOption = {
  tooltip: { trigger: 'axis' },
  grid: { left: 50, right: 16, top: 16, bottom: 24 },
  xAxis: { type: 'category', data: ['人力','采购','运营','营销','研发','行政'], axisLabel: { color: '#6a6a78' }, axisLine: { lineStyle: { color: '#2a2a35' } } },
  yAxis: { type: 'value', axisLabel: { color: '#6a6a78' }, splitLine: { lineStyle: { color: '#2a2a35' } } },
  series: [{ type: 'bar', data: [45,32,18,25,38,12], itemStyle: { color: '#3b82f6' } }],
};

export default function FinanceDashboard() {
  return (
    <>
      <h2 className="fin-page-title">财务总览</h2>
      <div className="kpi-grid">
        {kpis.map(k => (
          <div key={k.label} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className={`kpi-change ${k.up ? 'up' : 'down'}`}>{k.change}</div>
          </div>
        ))}
      </div>
      <div className="fin-chart-row">
        <div className="fin-chart-card wide">
          <div className="fin-chart-title">收支趋势</div>
          <Chart option={trendOption} className="fin-chart tall" />
        </div>
      </div>
      <div className="fin-chart-row">
        <div className="fin-chart-card">
          <div className="fin-chart-title">应收账款账龄分析</div>
          <Chart option={arApOption} />
        </div>
        <div className="fin-chart-card">
          <div className="fin-chart-title">费用结构分析</div>
          <Chart option={costOption} />
        </div>
      </div>
    </>
  );
}
