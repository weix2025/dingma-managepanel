import './page.css';

const taxItems = [
  { type: '增值税', period: '2025年8月', taxable: '2,847,600.00', tax: '370,188.00', deduct: '198,450.00', payable: '171,738.00', deadline: '2025-09-15', status: '未申报' },
  { type: '企业所得税', period: '2025年Q3', taxable: '1,086,900.00', tax: '271,725.00', prepaid: '180,000.00', payable: '91,725.00', deadline: '2025-10-15', status: '未申报' },
  { type: '增值税', period: '2025年7月', taxable: '2,540,000.00', tax: '330,200.00', deduct: '175,300.00', payable: '154,900.00', deadline: '2025-08-15', status: '已申报' },
  { type: '个人所得税', period: '2025年8月', taxable: '486,200.00', tax: '48,620.00', deduct: '0.00', payable: '48,620.00', deadline: '2025-09-15', status: '未申报' },
];

const statusColors: Record<string, string> = { '已申报': 'green', '未申报': 'orange', '逾期': 'red' };

export default function TaxPage() {
  return (
    <>
      <h2 className="fin-page-title">税务申报</h2>
      <table className="fin-table">
        <thead><tr><th>税种</th><th>所属期</th><th>应纳税额</th><th>应缴税额</th><th>申报截止</th><th>状态</th></tr></thead>
        <tbody>
          {taxItems.map((t, i) => (
            <tr key={i}>
              <td>{t.type}</td>
              <td>{t.period}</td>
              <td className="num-cell">{t.tax}</td>
              <td className="num-cell" style={{ fontWeight: 600 }}>{t.payable}</td>
              <td>{t.deadline}</td>
              <td><span className={`fin-tag ${statusColors[t.status]}`}>{t.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
