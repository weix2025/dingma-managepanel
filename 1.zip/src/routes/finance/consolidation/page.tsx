import './page.css';

const subs = [
  { name: '北京子公司', revenue: '3,200,000', profit: '480,000', assets: '5,600,000', status: '已提交' },
  { name: '上海子公司', revenue: '2,800,000', profit: '392,000', assets: '4,200,000', status: '已提交' },
  { name: '深圳子公司', revenue: '1,500,000', profit: '195,000', assets: '2,800,000', status: '待提交' },
];

const sc: Record<string, string> = { '已提交': 'green', '待提交': 'orange' };

export default function ConsolidationPage() {
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">合并报表</h2>
        <button type="button" className="btn btn-primary">生成合并报表</button>
      </div>
      <table className="fin-table">
        <thead><tr><th>子公司</th><th>营业收入</th><th>净利润</th><th>总资产</th><th>状态</th></tr></thead>
        <tbody>
          {subs.map(s => (
            <tr key={s.name}>
              <td>{s.name}</td>
              <td className="num-cell">{s.revenue}</td>
              <td className="num-cell">{s.profit}</td>
              <td className="num-cell">{s.assets}</td>
              <td><span className={`fin-tag ${sc[s.status]}`}>{s.status}</span></td>
            </tr>
          ))}
          <tr style={{ fontWeight: 600 }}>
            <td>合计（抵消前）</td>
            <td className="num-cell">7,500,000</td>
            <td className="num-cell">1,067,000</td>
            <td className="num-cell">12,600,000</td>
            <td />
          </tr>
        </tbody>
      </table>
    </>
  );
}
