import { Navigate } from '@modern-js/runtime/router';
export default () => <Navigate to="/finance/dashboard" replace />;
