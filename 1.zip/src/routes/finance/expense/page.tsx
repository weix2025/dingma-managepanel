import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import './page.css';

const expenses = [
  { id: 'BX-2025-0156', applicant: '张三丰', dept: '销售部', type: '差旅', amount: '8,520.00', date: '2025-08-12', status: '待审批' },
  { id: 'BX-2025-0155', applicant: '李四', dept: '研发部', type: '办公用品', amount: '2,340.00', date: '2025-08-11', status: '审批中' },
  { id: 'BX-2025-0154', applicant: '王五', dept: '市场部', type: '招待', amount: '5,680.00', date: '2025-08-10', status: '已通过' },
  { id: 'BX-2025-0153', applicant: '赵六', dept: '行政部', type: '交通', amount: '1,260.00', date: '2025-08-09', status: '已通过' },
  { id: 'BX-2025-0152', applicant: '周星星', dept: '财务部', type: '培训', amount: '12,000.00', date: '2025-08-08', status: '已驳回' },
  { id: 'BX-2025-0151', applicant: '曲丽丽', dept: '研发部', type: '差旅', amount: '6,890.00', date: '2025-08-07', status: '已付款' },
];

const statusColors: Record<string, string> = { '待审批': 'orange', '审批中': 'blue', '已通过': 'green', '已驳回': 'red', '已付款': 'cyan' };

export default function ExpensePage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">报销审批</h2>
        <button type="button" className="btn btn-primary">提交报销</button>
      </div>
      <Tabs items={['全部', '待审批', '审批中', '已通过', '已驳回']} active={tab} onChange={setTab} />
      <table className="fin-table" style={{ marginTop: 14 }}>
        <thead><tr><th>单号</th><th>申请人</th><th>部门</th><th>类型</th><th>金额</th><th>日期</th><th>状态</th></tr></thead>
        <tbody>
          {expenses.map(e => (
            <tr key={e.id}>
              <td className="code-cell">{e.id}</td>
              <td>{e.applicant}</td>
              <td>{e.dept}</td>
              <td>{e.type}</td>
              <td className="num-cell">{e.amount}</td>
              <td>{e.date}</td>
              <td><span className={`fin-tag ${statusColors[e.status]}`}>{e.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
