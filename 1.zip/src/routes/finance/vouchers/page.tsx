import { useState } from 'react';
import Tabs from '@/components/ui/Tabs';
import Button from '@/components/ui/Button';
import './page.css';

const vouchers = [
  { id: 'PZ-2025-0812', date: '2025-08-12', type: '收', summary: '收到客户货款-某某科技', debit: '285,000.00', credit: '', status: '已审核', by: '张会计' },
  { id: 'PZ-2025-0811', date: '2025-08-11', type: '付', summary: '支付供应商采购款', debit: '', credit: '152,300.00', status: '已审核', by: '李会计' },
  { id: 'PZ-2025-0810', date: '2025-08-10', type: '转', summary: '计提本月折旧费用', debit: '18,500.00', credit: '18,500.00', status: '待审核', by: '张会计' },
  { id: 'PZ-2025-0809', date: '2025-08-09', type: '收', summary: '收到投资收益', debit: '45,000.00', credit: '', status: '已审核', by: '王会计' },
  { id: 'PZ-2025-0808', date: '2025-08-08', type: '付', summary: '支付员工工资', debit: '', credit: '486,200.00', status: '已记账', by: '李会计' },
  { id: 'PZ-2025-0807', date: '2025-08-07', type: '转', summary: '结转本月销售成本', debit: '312,400.00', credit: '312,400.00', status: '已记账', by: '张会计' },
];

const statusColors: Record<string, string> = { '已审核': 'blue', '待审核': 'orange', '已记账': 'green', '已作废': 'red' };

export default function VouchersPage() {
  const [tab, setTab] = useState(0);
  return (
    <>
      <div className="fin-header">
        <h2 className="fin-page-title">凭证管理</h2>
        <div className="fin-header-actions">
          <Button variant="outline">批量审核</Button>
          <Button variant="primary">新增凭证</Button>
        </div>
      </div>
      <Tabs items={['全部', '待审核', '已审核', '已记账']} active={tab} onChange={setTab} />
      <table className="fin-table" style={{ marginTop: 14 }}>
        <thead><tr><th>凭证号</th><th>日期</th><th>类型</th><th>摘要</th><th>借方</th><th>贷方</th><th>状态</th><th>制单人</th></tr></thead>
        <tbody>
          {vouchers.map(v => (
            <tr key={v.id}>
              <td className="code-cell">{v.id}</td>
              <td>{v.date}</td>
              <td><span className={`fin-tag ${v.type === '收' ? 'green' : v.type === '付' ? 'red' : 'blue'}`}>{v.type}</span></td>
              <td>{v.summary}</td>
              <td className="num-cell">{v.debit}</td>
              <td className="num-cell">{v.credit}</td>
              <td><span className={`fin-tag ${statusColors[v.status]}`}>{v.status}</span></td>
              <td>{v.by}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
